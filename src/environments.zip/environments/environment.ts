export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyABJcF7Bo_C4HyQgsPeI3YSShiiLESEaaw",
    authDomain: "tools-app-3e967.firebaseapp.com",
    projectId: "tools-app-3e967",
    storageBucket: "tools-app-3e967.appspot.com",
    messagingSenderId: "218164778206",
    appId: "1:218164778206:web:a3259df28b089056671e4f"
  },
  hereMapsConfig: {
    appId: 'gN9JFAyj7HvzM0m34SBG',
    appCode: 'Wr8gfDNcAIzDTeMuWQwODg'
  },
  clientWebGoogleID: 1
};